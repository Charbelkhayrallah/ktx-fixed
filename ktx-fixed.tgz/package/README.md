# @charbelkh/ktx

**This is an unofficial, temporary fork of [`@kaelio/ktx`](https://www.npmjs.com/package/@kaelio/ktx) v0.16.0.**
It is not affiliated with or endorsed by Kaelio. For the real thing, install
`@kaelio/ktx`. Full docs: https://docs.kaelio.com/ktx

## Why this exists

In upstream 0.16.0, `ktx ingest` re-sends **every** table to the LLM on every
run, which exhausts API rate limits and can leave descriptions empty. This fork
carries two fixes so already-generated descriptions are reused.

| Before | After |
|---|---|
| Every `ktx ingest` regenerated all descriptions | Unchanged tables are reused |
| Ctrl-C mid-ingest lost all progress | Finished tables kept; only the rest run |
| Adding one table re-ran all of them | Only the new/changed table runs |

This restores the behavior ktx's own documentation already describes — per-stage
hashing and a per-table resume record.

## Install

```bash
npm uninstall -g @kaelio/ktx
npm i -g @charbelkh/ktx
```

The binary is still called `ktx`, so every command and doc works unchanged.
Uninstall upstream first — two packages providing the same `ktx` binary conflict.

## Changes from upstream (Apache-2.0 §4(b))

Modified, all in `packages/cli/src/context/scan/`:

- **`enrichment-state.ts`** — the descriptions/embeddings/relationships stage
  hashes now exclude `extractedAt`, a per-scan wall-clock timestamp that
  re-keyed every stage on each run and forced full LLM regeneration. Added
  `computeKtxTableDescriptionHash` for per-table cache keys.
- **`local-enrichment-artifacts.ts`** — the descriptions progress record stores a
  per-table hash map; `load()` no longer gates all-or-nothing on the batch hash.
- **`local-enrichment.ts`** — `generateDescriptions` recovers each table
  independently when its own hash still matches.

Upstream reports: [#347](https://github.com/Kaelio/ktx/issues/347) ·
[#348](https://github.com/Kaelio/ktx/issues/348). **When these land upstream this
fork will be deprecated** — go back to `npm i -g @kaelio/ktx`.

## Known gap

A rate-limited run that leaves empty descriptions is still recorded as a
completed stage, so a plain re-run won't retry them:

```bash
ktx ingest <connection-id> --stages descriptions
```

That reuses the good descriptions and regenerates only the empty ones.

## License

Apache-2.0, unchanged from upstream. Original work © Kaelio — see `LICENSE`.
