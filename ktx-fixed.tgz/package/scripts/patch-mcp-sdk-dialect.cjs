#!/usr/bin/env node
// Make @modelcontextprotocol/sdk advertise JSON Schema 2020-12 instead of draft-07.
//
// The SDK converts ktx's Zod v4 schemas for tools/list via toJsonSchemaCompat(),
// whose mapMiniTarget() returns 'draft-7' when no target is passed — and mcp.js
// never passes one. Zod then stamps draft-07 on every schema the server emits, and
// clients validating with a 2020-12-only validator (Claude Code uses Ajv 2020)
// reject the dialect and refuse to run the tool at all.
// Upstream bug: https://github.com/modelcontextprotocol/typescript-sdk/issues/745
// (still hardcoded in SDK 1.30.0, so bumping the SDK does not help).
//
// Flips only the "caller passed no target" branch, so an explicit 'draft-7'
// request is still honoured. ktx's own code is untouched.
//
// Wired to postinstall so it survives reinstalls. Idempotent — re-run any time:
//   node scripts/patch-mcp-sdk-dialect.cjs
// Never fails an install: on any surprise it warns and exits 0.

const fs = require('node:fs');
const path = require('node:path');

const FROM =
    /(function mapMiniTarget\([^)]*\)\s*\{\s*if\s*\(\s*!\s*\w+\s*\)\s*(?:\r?\n)?\s*return\s+)(['"])draft-7\2/;
const DONE =
    /function mapMiniTarget\([^)]*\)\s*\{\s*if\s*\(\s*!\s*\w+\s*\)\s*(?:\r?\n)?\s*return\s+(['"])draft-2020-12\1/;

function findSdk() {
    const pkg = path.join(__dirname, '..'); // scripts/ sits at the package root
    const candidates = [
        path.join(pkg, 'node_modules', '@modelcontextprotocol', 'sdk'), // nested
        path.join(pkg, '..', '@modelcontextprotocol', 'sdk'), // hoisted, unscoped pkg
        path.join(pkg, '..', '..', '@modelcontextprotocol', 'sdk'), // hoisted, scoped pkg
    ];
    return candidates.find((dir) => fs.existsSync(path.join(dir, 'package.json'))) ?? null;
}

try {
    const sdk = findSdk();
    if (!sdk) {
        throw new Error('@modelcontextprotocol/sdk not found');
    }
    const { version } = require(path.join(sdk, 'package.json'));

    let patched = 0;
    let already = 0;
    for (const build of ['esm', 'cjs']) {
        const file = path.join(sdk, 'dist', build, 'server', 'zod-json-schema-compat.js');
        if (!fs.existsSync(file)) continue;
        const src = fs.readFileSync(file, 'utf8');
        if (DONE.test(src)) {
            already += 1;
        } else if (FROM.test(src)) {
            fs.writeFileSync(file, src.replace(FROM, '$1$2draft-2020-12$2'), 'utf8');
            patched += 1;
        }
    }

    if (patched > 0) {
        console.log(`[ktx] mcp-sdk ${version}: tool schemas now advertise JSON Schema 2020-12`);
    } else if (already > 0) {
        console.log(`[ktx] mcp-sdk ${version}: dialect patch already applied`);
    } else {
        console.warn(`[ktx] mcp-sdk ${version}: dialect patch did not match — upstream may have fixed #745`);
    }
} catch (err) {
    console.warn(`[ktx] mcp-sdk dialect patch skipped: ${err.message}`);
}
